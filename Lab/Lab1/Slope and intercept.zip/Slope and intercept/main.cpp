#include <iostream>
#include <string>
#include <fstream>


//
//
//int main(){
//    using namespace std;
//    double sum1 = 0;
//    double array[37];
//    
//    
//    ifstream myfile("slopeXcol.txt");
//    
////    file.open(file);
//    if(myfile.is_open()){
//        
//        
//        
//        for(int i=0; 1<37; ++i){
//            
//            myfile >> array[i];
//            sum1+=array[i];
//        }
//    }
//    cout << "The X sum is" << sum1 <<endl;
//    myfile.close();
//    return 0;
//}

//
//
//
//
//
//
//
//
//
//
//
//int main(){
//    using namespace std;
//    double sum1 = 0;
//    double array[37];
//    
//    
//    ifstream myfile("slope&col.csv");
//    
////    file.open(file);
//    if(myfile.is_open()){
//
//        // slope calc
//        const double m = (dataY) / (dataX);
//        cout << endl << "The slope is: " << m << endl;
//
//        // get the final slope intercept form
//        const double b = dataY - (m*dataX);
//        cout << "The y intercept is: " << b<< endl;
//
//        // line equation
//        cout << "Slope Intercept form: "
//        << "y = " <<m << " *x +" << b<< endl;
//
//        }
//    }
//    cout << "The X sum is" << sum1 <<endl;
//    myfile.close();
//    return 0;
//}

using namespace std;

int main(){
    vector<double> dataX, dataY;
    double x, y;
    
    ifstream myfile("slopeXcol.csv");
    
    while (myfile >> x >> y){
        dataX.push_back(x);
        dataY.push_back(y);
    }
    
    for(inti(0); i <dataX.size(); i++)
        cout << dataX[i] <<"," << dataY[i] <<endl;
    
}